
// import React from 'react';
// import { render, screen, waitFor } from '@testing-library/react';
// import Product from './';

// describe('Product Component', () => {
//     jest.setTimeout(50000);
// it('renders the product section', async () => {
//     render(<Product />);
   
//     // Use waitFor to wait for the content to appear
//     await waitFor(() => {
       
//       expect(screen.getByText('The TinyLife Wellness Model')).toBeInTheDocument();
//       expect(screen.getByText('Tinylife Wellness is a predictive model that helps organizations at the forefront')).toBeInTheDocument();
//     }, { timeout: 5000 });

//     // Check if the Register button is rendered
//     expect(screen.getByText('Register')).toBeInTheDocument();
    
//     // Check if the product section image is rendered
//     expect(screen.getByAltText('web portal')).toBeInTheDocument();
//   });
// });

import React from "react";
import { render, screen, waitFor } from "@testing-library/react";
import Product from './';

describe("Product component", () => {
  it("renders the component correctly", async() => {
    render(<Product />);
  
    await waitFor(() => {
    expect(screen.getByText("The TinyLife Wellness")).toBeInTheDocument();
    expect(screen.getByText("Tinylife Wellness is a predictive model")).toBeInTheDocument();
    expect(screen.getByAltText("web portal")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Register" })).toBeInTheDocument();
    expect(screen.getByTestId("slideshow")).toBeInTheDocument();
  });
});

});
    
       

